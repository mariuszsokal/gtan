--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.1
-- Dumped by pg_dump version 9.6.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT username;
ALTER TABLE ONLY public.users DROP CONSTRAINT mail;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: users; Type: TABLE; Schema: public; Owner: lssrp
--

CREATE TABLE users (
    id bigint NOT NULL,
    username character(32) NOT NULL,
    password character(64) NOT NULL,
    mail character varying NOT NULL,
    register_time timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE users OWNER TO lssrp;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: lssrp
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_id_seq OWNER TO lssrp;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: lssrp
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: lssrp
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: lssrp
--

COPY users (id, username, password, mail, register_time) FROM stdin;
\.
COPY users (id, username, password, mail, register_time) FROM '$$PATH$$/2127.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: lssrp
--

SELECT pg_catalog.setval('users_id_seq', 6, true);


--
-- Name: users mail; Type: CONSTRAINT; Schema: public; Owner: lssrp
--

ALTER TABLE ONLY users
    ADD CONSTRAINT mail UNIQUE (mail);


--
-- Name: users username; Type: CONSTRAINT; Schema: public; Owner: lssrp
--

ALTER TABLE ONLY users
    ADD CONSTRAINT username UNIQUE (username);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: lssrp
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (username);


--
-- PostgreSQL database dump complete
--

